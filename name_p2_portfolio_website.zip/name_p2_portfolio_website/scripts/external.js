// window.alert("good morning milan");

var today = new Date();
// window.alert(today);

var year = today.getFullYear();
// window.alert("It is year " + year);


var el = document.getElementById("year");
el.innerHTML = year;